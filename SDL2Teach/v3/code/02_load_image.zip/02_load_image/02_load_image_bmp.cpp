#include <SDL2/SDL.h>

// 窗口
SDL_Window *Window = NULL;
// 窗口表面
SDL_Surface *WindowScreen = NULL;
// 图片表面
SDL_Surface *Surface = NULL;

int Init()
{
  SDL_Init(SDL_INIT_VIDEO);
  // 创建窗口
  Window = SDL_CreateWindow("02_load_image_bmp", SDL_WINDOWPOS_CENTERED, SDL_WINDOWPOS_CENTERED, 400, 240, SDL_WINDOW_SHOWN);
  if (Window == NULL)
    return -1;

  // 获取Window的表面
  WindowScreen = SDL_GetWindowSurface(Window);
  if (WindowScreen == NULL)
    return -2;
  return 0;
}

int LoadSurface()
{
//加载图片 BMP格式
  Surface = SDL_LoadBMP("hello.bmp");
  if (Surface == NULL)
    return -1;
  return 0;
}

void Destroy()
{
  SDL_FreeSurface(WindowScreen);
  SDL_FreeSurface(Surface);
  SDL_DestroyWindow(Window);
  SDL_Quit();
}


int main(int args, char *argv[])
{
  //初始化
  if (Init() != 0)
    return -1;
  //加载图片
  if (LoadSurface() != 0)
    return -2;
  //粘贴表面
  SDL_BlitScaled(Surface, NULL, WindowScreen, NULL);
//更新窗口
  SDL_UpdateWindowSurface(Window);
  SDL_Delay(2000);
  Destroy();
  return 0;
}
