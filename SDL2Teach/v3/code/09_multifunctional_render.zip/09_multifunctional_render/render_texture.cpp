#include <SDL2/SDL.h>
#include <SDL2/SDL_image.h>
#include <string>


class Window
{
    enum
    {
        titleBarHeight=20
    };
public:
    Window();
    ~Window();
    void clear();
    bool draw();
    void present();
protected:
    int init();
    void destroy();
    void drawWindowBorder(const SDL_Color c);
    bool setViewport(const SDL_Rect* rect);
    bool renderSurface(SDL_Surface *src, const SDL_Rect *srcrect, const SDL_Rect *dstrect);
    bool renderSurfaceEx(SDL_Surface *src, const SDL_Rect *srcrect, const SDL_Rect *dstrect, const double angle, const SDL_Point* center, const SDL_RendererFlip flip);
private:
    SDL_Window *m_window;
    SDL_Renderer *m_render;
    bool m_bool;
};
Window::Window()
{
    m_window = nullptr;
    m_render = nullptr;

    if (Window::init() != 0)
    {
        SDL_Log("%d:Init err %d", __LINE__, SDL_GetError());
        m_bool = false;
    }
    else
        m_bool = true;
}
Window::~Window()
{
    destroy();
}
int Window::init()
{
    SDL_Init(SDL_INIT_VIDEO);
    // ��������
    m_window = SDL_CreateWindow("Window", SDL_WINDOWPOS_CENTERED, SDL_WINDOWPOS_CENTERED, 640, 400, SDL_WINDOW_SHOWN | SDL_WINDOW_BORDERLESS);

    if (m_window == nullptr)
    {
        return -1;
    }

    // ������Ⱦ��
    m_render = SDL_CreateRenderer(m_window, -1, SDL_RENDERER_ACCELERATED);

    if ( m_render == nullptr)
    {
        return -2;
    }

    //������Ⱦ��ɫ �˴�Ϊ��ɫ
    SDL_SetRenderDrawColor(m_render, 0xff, 0xff, 0xff, 0xff);
    //����֧��͸����Ⱦ����
    SDL_SetRenderDrawBlendMode(m_render,SDL_BLENDMODE_BLEND);
    return 0;
}

void Window::clear()
{
    SDL_RenderClear(m_render);
}

void Window::present()
{
    SDL_RenderPresent(m_render);
}

//��������
void Window::destroy()
{
    if (m_render != nullptr)
        SDL_DestroyRenderer(m_render);

    if (m_window != nullptr)
        SDL_DestroyWindow(m_window);

    SDL_Quit();
}

bool Window::renderSurface(SDL_Surface *src, const SDL_Rect *srcrect, const SDL_Rect *dstrect)
{
    SDL_Texture *tmp = nullptr;
    tmp = SDL_CreateTextureFromSurface(m_render, src);

    if (tmp == nullptr)
    {
        SDL_Log("render Surface Error:Create Texture From Surface Error:%s", SDL_GetError());
        return false;
    }

    if (SDL_RenderCopy(m_render, tmp, srcrect, dstrect) != 0)
    {
        SDL_Log("render Surface Error:Render Copy Error:%s", SDL_GetError());
        return false;
    }

    SDL_DestroyTexture(tmp);
    return true;
}

bool Window::renderSurfaceEx(SDL_Surface *src, const SDL_Rect *srcrect, const SDL_Rect *dstrect, const double angle, const SDL_Point* center, const SDL_RendererFlip flip)
{
    SDL_Texture *tmp = nullptr;
    tmp = SDL_CreateTextureFromSurface(m_render, src);

    if (tmp == nullptr)
    {
        SDL_Log("render Surface Error:Create Texture From Surface Error:%s", SDL_GetError());
        return false;
    }

    if (SDL_RenderCopyEx(m_render, tmp, srcrect, dstrect, angle, center, flip) != 0)
    {
        SDL_Log("render Surface Error:Render Copy Error:%s", SDL_GetError());
        return false;
    }

    SDL_DestroyTexture(tmp);
    return true;
}

bool Window::setViewport(const SDL_Rect *rect)
{
    return (SDL_RenderSetViewport(m_render,rect)==0?true:false);
}

void Window::drawWindowBorder(const SDL_Color c)
{
    // ���ϴ���Ⱦ����ɫ��������
    SDL_Color draw_color;
	SDL_GetRenderDrawColor(m_render, &draw_color.r, &draw_color.g,&draw_color.b, &draw_color.a);
    // ��Ⱦ�װ�
    SDL_SetRenderDrawColor(m_render, 0xff, 0xff, 0xff,c.a);
    SDL_RenderFillRect(m_render,nullptr);
    //  ���õ�ǰ��Ⱦ��ɫ
    SDL_SetRenderDrawColor(m_render, c.r, c.g,c.b, c.a);
    // ��ȡ��ǰ��ͼ����
    SDL_Rect area;
    // ������
    SDL_Rect title;
    SDL_RenderGetViewport(m_render,&area);
    title.x=0;
    title.y=0;
    title.w=area.w;
    title.h=titleBarHeight;
    SDL_RenderDrawRect(m_render,nullptr);
    SDL_RenderFillRect(m_render,&title);
}
bool Window::draw()
{
SDL_Texture *texture=nullptr;
 SDL_Rect  texture_rect= {10,10,200,200};
texture=SDL_CreateTexture(m_render,SDL_PIXELFORMAT_RGBA8888,SDL_TEXTUREACCESS_TARGET,200,200);
SDL_SetRenderTarget(m_render,texture);
Window::clear();
Window::drawWindowBorder({0xff,0,0,0xff});
Window::present();
SDL_SetRenderTarget(m_render,nullptr);
SDL_RenderCopy(m_render,texture,nullptr,&texture_rect);
}
int main(int args, char *argv[])
{
    Window main_window;
    main_window.clear();
    main_window.draw();
    main_window.present();
    SDL_Delay(2000);
    return 0;
}
