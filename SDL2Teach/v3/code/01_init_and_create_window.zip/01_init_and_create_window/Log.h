#ifndef PLOG_H
#define PLOG_H
#include <cstdio>
#include <stdarg.h>

  int plog (const char *fmt, ...)
  {
    FILE *f = nullptr;
    static int first_run = 1;
    int re = 0;
    va_list l;
      va_start (l, fmt);
      f = fopen ("SDL.log", first_run ? "w" : "ab+");
    if (f != nullptr)
      {
	re = vfprintf (f, fmt, l);
	vprintf (fmt, l);
      }
    va_end (l);
    fclose (f);
    first_run = 0;
    return re;
  }

#define PLOG  plog("\n%s\t%s\t%d\t%s\n", __FILE__, __func__, __LINE__,SDL_GetError())
#endif
