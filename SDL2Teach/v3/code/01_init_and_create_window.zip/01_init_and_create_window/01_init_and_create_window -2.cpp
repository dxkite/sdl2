#include <SDL2/SDL.h>
#include "Log.h"
// 窗口
SDL_Window *Window = NULL;
// 窗口表面
SDL_Surface *WindowScreen = NULL;

//初始化函数
int Init()
{
    SDL_Init(SDL_INIT_VIDEO);
    // 创建窗口
    Window = SDL_CreateWindow("SDL_Window", SDL_WINDOWPOS_CENTERED, SDL_WINDOWPOS_CENTERED, 240, 400, SDL_WINDOW_SHOWN|SDL_WINDOW_BORDERLESS);
    if (Window == NULL)
    {
        PLOG;
        return -1;
    }

    // 获取Window的表面
    WindowScreen = SDL_GetWindowSurface(Window);
    if (WindowScreen == NULL)
    {
        PLOG;
        return -2;
    }
    return 0;
}


//清理函数
void Destroy()
{
    SDL_FreeSurface(WindowScreen);
    SDL_DestroyWindow(Window);
    SDL_Quit();
}


int main(int args, char *argv[])
{
    if (Init() != 0)
        return -1;
    //填充窗口
    SDL_FillRect(WindowScreen, NULL, SDL_MapRGB(WindowScreen->format, 0x00, 0xFF, 0xFF));
//更新窗口
    SDL_UpdateWindowSurface(Window);
    SDL_Delay(2000);
    Destroy();
    return 0;
}
