#include <SDL2/SDL.h>
#include <SDL2/SDL_image.h>
#include <cstdio>
// 窗口
SDL_Window *Window = NULL;
// 窗口表面
SDL_Surface *WindowScreen = NULL;
// 图片表面
SDL_Surface *Surface = NULL;
// 创建的表面
SDL_Surface *created = NULL;

int Init()
{
    SDL_Init(SDL_INIT_VIDEO);
    // 创建窗口
    Window = SDL_CreateWindow("03_create_surface", SDL_WINDOWPOS_CENTERED, SDL_WINDOWPOS_CENTERED, 400, 240, SDL_WINDOW_SHOWN);

    if (Window == NULL)
        return -1;

    // 获取Window的表面
    WindowScreen = SDL_GetWindowSurface(Window);

    if (WindowScreen == NULL)
        return -2;

    return 0;
}
const int bitmap_w = 2, bitmap_h = 2;
//表面数据
Uint32 bitmap[] =
{
    0xff00007f,
    0xff0000ff,
    0x00ff00ff,
    0x0000ffff,
};
int CreateSurface()
{
    created = SDL_CreateRGBSurfaceFrom((void *) bitmap, bitmap_w, bitmap_h, sizeof(Uint32) * 8, bitmap_w * sizeof(Uint32) , 0xFF000000, 0x00FF0000, 0x0000FF00, 0x000000FF);

    if (created == NULL)
        return -1;

    return 0;
}
int LoadSurface()
{
//加载图片
    Surface = IMG_Load("clip.png");

    if (Surface == NULL)
        return -1;

    return 0;
}
void Destroy()
{
    SDL_FreeSurface(WindowScreen);
    SDL_FreeSurface(Surface);
    SDL_FreeSurface(created);
    SDL_DestroyWindow(Window);
    SDL_Quit();
}


int main(int args, char *argv[])
{
    //初始化
    if (Init() != 0)
        return -1;

    //创建表面
    if (CreateSurface() != 0)
        return -2;

    //加载图片
    if (LoadSurface() != 0)
        return -3;

    //粘贴表面
    SDL_BlitScaled(Surface, NULL, WindowScreen, NULL);
    //粘贴位图
    SDL_BlitScaled(created, NULL, WindowScreen, NULL);
    //更新窗口
    SDL_UpdateWindowSurface(Window);
    SDL_Delay(2000);
    Destroy();
    return 0;
}
