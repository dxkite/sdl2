#include <SDL2/SDL.h>
#include <SDL2/SDL_image.h>
#include <string>


class Window
{
public:
    Window();
    ~Window();
    void clear();
    void draw();
    void present();
protected:
    int init();
    void destroy();
    bool renderSurface(SDL_Surface *src, const SDL_Rect *srcrect, const SDL_Rect *dstrect);
private:
    SDL_Window *m_window;
    SDL_Renderer *m_render;
    bool m_bool;
};
Window::Window()
{
    m_window = nullptr;
    m_render = nullptr;

    if (Window::init() != 0)
    {
        SDL_Log("%d:Init err %d", __LINE__, SDL_GetError());
        m_bool = false;
    }
    else
        m_bool = true;
}
Window::~Window()
{
    destroy();
}
int Window::init()
{
    SDL_Init(SDL_INIT_VIDEO);
    // ��������
    m_window = SDL_CreateWindow("Window", SDL_WINDOWPOS_CENTERED, SDL_WINDOWPOS_CENTERED, 640, 400, SDL_WINDOW_SHOWN | SDL_WINDOW_BORDERLESS);

    if (m_window == nullptr)
    {
        return -1;
    }

    // ������Ⱦ��
    m_render = SDL_CreateRenderer(m_window, -1, SDL_RENDERER_ACCELERATED);

    if ( m_render == nullptr)
    {
        return -2;
    }

    //������Ⱦ��ɫ �˴�Ϊ��ɫ
    SDL_SetRenderDrawColor(m_render, 0xff, 0xff, 0xff, 0xff);
    return 0;
}

void Window::clear()
{
    SDL_RenderClear(m_render);
}

void Window::present()
{
    SDL_RenderPresent(m_render);
}

//��������
void Window::destroy()
{
    if (m_render != nullptr)
        SDL_DestroyRenderer(m_render);

    if (m_window != nullptr)
        SDL_DestroyWindow(m_window);

    SDL_Quit();
}

bool Window::renderSurface(SDL_Surface *src, const SDL_Rect *srcrect, const SDL_Rect *dstrect)
{
    SDL_Texture *tmp = nullptr;
    tmp = SDL_CreateTextureFromSurface(m_render, src);

    if (tmp == nullptr)
    {
        SDL_Log("render Surface Error:Create Texture From Surface Error:%s", SDL_GetError());
        return false;
    }

    if (SDL_RenderCopy(m_render, tmp, srcrect, dstrect) != 0)
    {
        SDL_Log("render Surface Error:Render Copy Error:%s", SDL_GetError());
        return false;
    }

    SDL_DestroyTexture(tmp);
    return true;
}

void Window::draw()
{
    Window::renderSurface(IMG_Load("hello.png"), nullptr, nullptr);
}
int main(int args, char *argv[])
{
    Window main_window;
    main_window.clear();
    main_window.draw();
    main_window.present();
    SDL_Delay(2000);
    return 0;
}
