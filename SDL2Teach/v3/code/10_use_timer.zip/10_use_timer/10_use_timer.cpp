#include <SDL2/SDL.h>
#include <SDL2/SDL_image.h>
#include <SDL2/SDL_ttf.h>
#include <string>


class Window
{
    enum
    {
        titleBarHeight=20
    };
public:
    Window();
    ~Window();
    void clear();
    bool draw();
    void present();
protected:
    int init();
    void destroy();
    void drawWindowBorder(const SDL_Color c);
    bool setViewport(const SDL_Rect* rect);
    bool renderSurface(SDL_Surface *src, const SDL_Rect *srcrect, const SDL_Rect *dstrect);
    bool renderSurfaceEx(SDL_Surface *src, const SDL_Rect *srcrect, const SDL_Rect *dstrect, const double angle, const SDL_Point* center, const SDL_RendererFlip flip);
private:
    SDL_Window *m_window;
    SDL_Renderer *m_render;
    bool m_bool;
};
Window::Window()
{
    m_window = nullptr;
    m_render = nullptr;

    if (Window::init() != 0)
    {
        SDL_Log("%d:Init err %d", __LINE__, SDL_GetError());
        m_bool = false;
    }
    else
        m_bool = true;
}
Window::~Window()
{
    destroy();
}
int Window::init()
{
    SDL_Init(SDL_INIT_EVERYTHING);
    // ��������
    m_window = SDL_CreateWindow("Window", SDL_WINDOWPOS_CENTERED, SDL_WINDOWPOS_CENTERED, 640, 400, SDL_WINDOW_SHOWN | SDL_WINDOW_BORDERLESS);

    if (m_window == nullptr)
    {
        return -1;
    }

    // ������Ⱦ��
    m_render = SDL_CreateRenderer(m_window, -1, SDL_RENDERER_ACCELERATED);

    if ( m_render == nullptr)
    {
        return -2;
    }

    //������Ⱦ��ɫ �˴�Ϊ��ɫ
    SDL_SetRenderDrawColor(m_render, 0xff, 0xff, 0xff, 0xff);
    //����֧��͸����Ⱦ����
    SDL_SetRenderDrawBlendMode(m_render,SDL_BLENDMODE_BLEND);
    return 0;
}

void Window::clear()
{
    SDL_RenderClear(m_render);
}

void Window::present()
{
    SDL_RenderPresent(m_render);
}

//��������
void Window::destroy()
{
    if (m_render != nullptr)
        SDL_DestroyRenderer(m_render);

    if (m_window != nullptr)
        SDL_DestroyWindow(m_window);

    SDL_Quit();
}

bool Window::renderSurface(SDL_Surface *src, const SDL_Rect *srcrect, const SDL_Rect *dstrect)
{
    SDL_Texture *tmp = nullptr;
    tmp = SDL_CreateTextureFromSurface(m_render, src);

    if (tmp == nullptr)
    {
        SDL_Log("render Surface Error:Create Texture From Surface Error:%s", SDL_GetError());
        return false;
    }

    if (SDL_RenderCopy(m_render, tmp, srcrect, dstrect) != 0)
    {
        SDL_Log("render Surface Error:Render Copy Error:%s", SDL_GetError());
        return false;
    }

    SDL_DestroyTexture(tmp);
    return true;
}

bool Window::renderSurfaceEx(SDL_Surface *src, const SDL_Rect *srcrect, const SDL_Rect *dstrect, const double angle, const SDL_Point* center, const SDL_RendererFlip flip)
{
    SDL_Texture *tmp = nullptr;
    tmp = SDL_CreateTextureFromSurface(m_render, src);

    if (tmp == nullptr)
    {
        SDL_Log("render Surface Error:Create Texture From Surface Error:%s", SDL_GetError());
        return false;
    }

    if (SDL_RenderCopyEx(m_render, tmp, srcrect, dstrect, angle, center, flip) != 0)
    {
        SDL_Log("render Surface Error:Render Copy Error:%s", SDL_GetError());
        return false;
    }

    SDL_DestroyTexture(tmp);
    return true;
}

bool Window::setViewport(const SDL_Rect *rect)
{
    return (SDL_RenderSetViewport(m_render,rect)==0?true:false);
}

void Window::drawWindowBorder(const SDL_Color c)
{
    // ���ϴ���Ⱦ����ɫ��������
    SDL_Color draw_color;
    SDL_GetRenderDrawColor(m_render, &draw_color.r, &draw_color.g,&draw_color.b, &draw_color.a);
    // ��Ⱦ�װ�
    SDL_SetRenderDrawColor(m_render, 0xff, 0xff, 0xff,c.a);
    SDL_RenderFillRect(m_render,nullptr);
    //  ���õ�ǰ��Ⱦ��ɫ
    SDL_SetRenderDrawColor(m_render, c.r, c.g,c.b, c.a);
    // ��ȡ��ǰ��ͼ����
    SDL_Rect area;
    // ������
    SDL_Rect title;
    SDL_RenderGetViewport(m_render,&area);
    title.x=0;
    title.y=0;
    title.w=area.w;
    title.h=titleBarHeight;
    SDL_RenderDrawRect(m_render,nullptr);
    SDL_RenderFillRect(m_render,&title);
}

Uint32 callbackfunc(Uint32 interval, void *param)
{
    //�����˳�
    *(bool*)param=true;
    return interval;
}


bool Window::draw()
{
    TTF_Init();
    TTF_Font *myfont=TTF_OpenFont("my.ttf",20);
    if (myfont==nullptr)
    {
        SDL_Log("Open Font Error %s",SDL_GetError());
        return false;
    }
//��¼ʱ��
    Uint32 times=0;
//�˳���ʱ��
    bool Quit=false;
//�ı�����
    char text[80];
// ��ʱ��
    SDL_TimerID timer=SDL_AddTimer(2000,callbackfunc,&Quit);
    SDL_Rect rect;
    rect.x=100;
    rect.y=100;
    // ��ʾ����
    SDL_Surface *tmp=nullptr;
    // ��ʱ�����е���ʾ
    while(!Quit)
    {
        Window::clear();
        times=SDL_GetTicks();
        sprintf(text,"Time Passed:%d",times);
        tmp=TTF_RenderUTF8_Blended(myfont,text, {0,0,0xff,0xff});
        rect.w=tmp->w;
        rect.h=tmp->h;
        Window::renderSurface(tmp,nullptr,&rect);
        SDL_FreeSurface(tmp);
        tmp=nullptr;
        Window::present();
    }
    //��ʱ����ɺ����ʾ
    Window::clear();
    sprintf(text,"Time Pass:%d,callback function be call",times);
    tmp=TTF_RenderUTF8_Blended(myfont,text, {0xff,0,0,0xff});
    rect.w=tmp->w;
    rect.h=tmp->h;
    Window::renderSurface(tmp,nullptr,&rect);
    SDL_FreeSurface(tmp);
    tmp=nullptr;
    TTF_Quit();
    SDL_RemoveTimer(timer);
}

int main(int args, char *argv[])
{
    Window main_window;
    main_window.clear();
    main_window.draw();
    main_window.present();
    SDL_Delay(2000);
    return 0;
}
