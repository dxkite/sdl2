//加载非bmp图片
#include <SDL2/SDL.h>
#include <SDL2/SDL_ttf.h>
#include <cstdio>
// 窗口
SDL_Window *Window = NULL;
// 窗口表面
SDL_Surface *WindowScreen = NULL;
// 图片表面
SDL_Surface *Surface = NULL;

#if defined(__ANDROID__)
const char fpath[] = "/system/fonts/DroidSansFallback.ttf";
const int fsize = 40;
#else
const char fpath[] = "my.ttf";
const int fsize = 20;
#endif

int Init()
{
    SDL_Init(SDL_INIT_VIDEO);
    // 创建窗口
    Window = SDL_CreateWindow("04_use_ttf", SDL_WINDOWPOS_CENTERED, SDL_WINDOWPOS_CENTERED, 400, 240, SDL_WINDOW_SHOWN);

    if (Window == NULL)
        return -1;

    // 获取Window的表面
    WindowScreen = SDL_GetWindowSurface(Window);

    if (WindowScreen == NULL)
        return -2;

    return 0;
}


void Destroy()
{
    SDL_FreeSurface(WindowScreen);
    SDL_FreeSurface(Surface);
    SDL_DestroyWindow(Window);
    SDL_Quit();
}


int main(int args, char *argv[])
{
    //初始化SDL
    if (Init() != 0)
        return -1;


    //   初始化字体
    TTF_Init();
    //字体
    TTF_Font *Font = NULL;
//加载字体文件
    Font = TTF_OpenFont(fpath, fsize);

    if (Font == NULL)
        return -2;

    SDL_Color fg = {0xff, 0, 0, 0xff} ;
    SDL_Rect pos;
    pos.x = 0;
    pos.y = 0;


    TTF_SetFontStyle(Font, TTF_STYLE_BOLD);
    Surface = TTF_RenderUTF8_Blended(Font, "TTF_STYLE_BOLD", fg);

    if (Surface == NULL)
        return -3;

    pos.w = Surface->w;
    pos.h =  Surface->h;
    //粘贴表面
    SDL_BlitScaled(Surface, NULL, WindowScreen, &pos);
    SDL_FreeSurface(Surface);
    Surface = NULL;



TTF_SetFontStyle(Font, TTF_STYLE_ITALIC );
    Surface = TTF_RenderUTF8_Blended(Font, "TTF_STYLE_ITALIC", fg);

    if (Surface == NULL)
        return -4;

    pos.x = 0;
    pos.y = pos.h;
    pos.w = Surface->w;
    pos.h =  Surface->h;
    //粘贴表面
    SDL_BlitScaled(Surface, NULL, WindowScreen, &pos);
    SDL_FreeSurface(Surface);
    Surface = NULL;


    TTF_SetFontStyle(Font,TTF_STYLE_UNDERLINE);
    Surface = TTF_RenderUTF8_Blended(Font, "TTF_STYLE_UNDERLINE", fg);

    if (Surface == NULL)
        return -5;

    pos.x = 0;
    pos.y = pos.h*2;
    pos.w = Surface->w;
    pos.h =  Surface->h;
    //粘贴表面
    SDL_BlitScaled(Surface, NULL, WindowScreen, &pos);
    SDL_FreeSurface(Surface);
    Surface = NULL;


    TTF_SetFontStyle(Font,TTF_STYLE_STRIKETHROUGH);
    Surface = TTF_RenderUTF8_Blended(Font, "TTF_STYLE_STRIKETHROUGH", fg);

    if (Surface == NULL)
        return -5;

    pos.x = 0;
    pos.y = pos.h*3;
    pos.w = Surface->w;
    pos.h =  Surface->h;
    //粘贴表面
    SDL_BlitScaled(Surface, NULL, WindowScreen, &pos);
    SDL_FreeSurface(Surface);
    Surface = NULL;
//更新窗口
    SDL_UpdateWindowSurface(Window);
    SDL_Delay(2000);
    //释放字体
    TTF_CloseFont(Font);
    //退出
    TTF_Quit();
    Destroy();
    return 0;
}
