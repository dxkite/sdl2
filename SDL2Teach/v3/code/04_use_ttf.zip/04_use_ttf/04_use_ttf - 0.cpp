//加载非bmp图片
#include <SDL2/SDL.h>
#include <SDL2/SDL_ttf.h>
#include <cstdio>
// 窗口
SDL_Window *Window = NULL;
// 窗口表面
SDL_Surface *WindowScreen = NULL;
// 图片表面
SDL_Surface *Surface = NULL;

#if defined(__ANDROID__)
const char fpath[] = "/system/fonts/DroidSansFallback.ttf";
const int fsize = 40;
#else
const char fpath[] = "C:/Windows/Fonts/msyh.ttf";
const int fsize = 20;
#endif

int Init()
{
    SDL_Init(SDL_INIT_VIDEO);
    // 创建窗口
    Window = SDL_CreateWindow("04_use_ttf", SDL_WINDOWPOS_CENTERED, SDL_WINDOWPOS_CENTERED, 400, 240, SDL_WINDOW_SHOWN);

    if (Window == NULL)
        return -1;

    // 获取Window的表面
    WindowScreen = SDL_GetWindowSurface(Window);

    if (WindowScreen == NULL)
        return -2;

    return 0;
}


void Destroy()
{
    SDL_FreeSurface(WindowScreen);
    SDL_FreeSurface(Surface);
    SDL_DestroyWindow(Window);
    SDL_Quit();
}


int main(int args, char *argv[])
{
    //初始化SDL
    if (Init() != 0)
        return -1;

    //   初始化字体
    TTF_Init();
    //字体
    TTF_Font *Font = NULL;
	//加载字体文件
    Font = TTF_OpenFont(fpath, fsize);

    if (Font == NULL)
        return -2;

    SDL_Color fg = {0xff, 0, 0, 0xff},fg2 = {0,0xff, 0, 0xff};
    SDL_Rect pos;
    pos.x = 0;
    pos.y = 0;
    int fw = 0, fh = 0;
    Surface = TTF_RenderUTF8_Blended(Font, "Solid 渲染UTF-8", fg);

    if (Surface == NULL)
        return -3;

    //通过函数获取单行长宽
    TTF_SizeUTF8(Font, "Solid 渲染UTF-8", &fw, &fh);
    pos.w = fw;
    pos.h = fh;
    //粘贴表面
    SDL_BlitScaled(Surface, NULL, WindowScreen, &pos);
    SDL_FreeSurface(Surface);
    Surface = NULL;
    Surface = TTF_RenderUTF8_Blended_Wrapped(Font, "渲染UTF-8折行渲染UTF-8折行渲染UTF-8 折行渲染UTF-8 折行渲染UTF-8 折行渲染UTF-8", fg2,/*行宽*/ 400);

    if (Surface == NULL)
        return -4;

    pos.x = 0;
    pos.y = fh;
    //获取表面的宽高
    pos.w = Surface->w;
    pos.h = Surface->h;
    SDL_BlitScaled(Surface, NULL, WindowScreen, &pos);
//更新窗口
    SDL_UpdateWindowSurface(Window);
    SDL_Delay(2000);
    //释放字体
    TTF_CloseFont(Font);
    //退出
    TTF_Quit();
    Destroy();
    return 0;
}
