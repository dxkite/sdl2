//加载非bmp图片
#include <SDL2/SDL.h>
#include <SDL2/SDL_image.h>
// 窗口
SDL_Window *Window = NULL;
// 窗口表面
SDL_Surface *WindowScreen = NULL;
// 图片表面
SDL_Surface *Surface = NULL;

int Init()
{
    SDL_Init(SDL_INIT_VIDEO);
    //初始化IMG
    IMG_Init(IMG_INIT_PNG);
    // 创建窗口
    Window = SDL_CreateWindow("02_load_image", SDL_WINDOWPOS_CENTERED, SDL_WINDOWPOS_CENTERED, 400, 240, SDL_WINDOW_SHOWN);

    if (Window == NULL)
        return -1;

    // 获取Window的表面
    WindowScreen = SDL_GetWindowSurface(Window);

    if (WindowScreen == NULL)
        return -2;

    return 0;
}

int LoadSurface()
{
//加载图片
    Surface = IMG_Load("clip.png");

    if (Surface == NULL)
        return -1;

    return 0;
}

void Destroy()
{
    SDL_FreeSurface(WindowScreen);
    SDL_FreeSurface(Surface);
    SDL_DestroyWindow(Window);
    IMG_Quit();
    SDL_Quit();
}


int main(int args, char *argv[])
{
    //初始化
    if (Init() != 0)
        return -1;

    //加载图片
    if (LoadSurface() != 0)
        return -2;

    //剪切
    SDL_Rect clip =
    {
        0, 0, 200, 120
    };
    //绘制位置
    SDL_Rect pos =
    {
        50, 50, 200, 120
    };
    //粘贴表面
    SDL_BlitScaled(Surface, &clip, WindowScreen, &pos);
    //更新窗口
    SDL_UpdateWindowSurface(Window);
    SDL_Delay(2000);
    Destroy();
    return 0;
}
