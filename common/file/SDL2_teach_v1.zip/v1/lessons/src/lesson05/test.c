#include "DXErr.h"



int main()
{
	using namespace DXkite;
	DXErr f;
	f<< "@洋蛋炒饭 " << "@傻傻_痴痴 " <<Endl << Time <<Endl<< Date << Endl << DXFile << Endl<<"可以用了！"<<Endl<<TimeNow;
}